WEIGHTS = {"relevance": .30, "historical_performance": .25, "trend_strength": .20,
           "audience_fit": .15, "production_feasibility": .10}
def score(components: dict) -> dict:
    """Weighted 0-100 score. Missing inputs -> renormalized provisional score;
    no inputs -> unsupported. Never fabricates values."""
    for k, v in components.items():
        if k not in WEIGHTS: raise ValueError(f"unknown component {k}")
        if v is not None and not 0 <= v <= 100: raise ValueError(f"{k} must be 0-100")
    have = {k: v for k, v in components.items() if v is not None}
    missing = [k for k in WEIGHTS if k not in have]
    if not have:
        return {"score": None, "status": "insufficiently_supported", "missing": missing}
    total_w = sum(WEIGHTS[k] for k in have)
    s = sum(v * WEIGHTS[k] for k, v in have.items()) / total_w
    return {"score": round(s, 2), "status": "provisional" if missing else "complete", "missing": missing}
