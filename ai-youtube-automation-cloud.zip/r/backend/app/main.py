from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .config import ALLOWED_ORIGINS
from .database import Base, engine
from . import models  # noqa
from .services.scoring_service import score
Base.metadata.create_all(engine)
app = FastAPI(title="AI YouTube Automation Cloud")
app.add_middleware(CORSMiddleware, allow_origins=ALLOWED_ORIGINS, allow_methods=["GET", "POST"], allow_headers=["*"])
class ScoreIn(BaseModel):
    relevance: float | None = Field(None, ge=0, le=100)
    historical_performance: float | None = Field(None, ge=0, le=100)
    trend_strength: float | None = Field(None, ge=0, le=100)
    audience_fit: float | None = Field(None, ge=0, le=100)
    production_feasibility: float | None = Field(None, ge=0, le=100)
@app.get("/health")
def health(): return {"status": "ok"}
@app.post("/trends/score")
def trends_score(body: ScoreIn):
    try: return score(body.model_dump())
    except ValueError as e: raise HTTPException(422, str(e))
