import pytest
from app.services.scoring_service import score
def test_full():
    r = score(dict(relevance=100, historical_performance=100, trend_strength=100, audience_fit=100, production_feasibility=100))
    assert r["score"] == 100 and r["status"] == "complete"
def test_provisional_renormalized():
    r = score(dict(relevance=80, historical_performance=None, trend_strength=None, audience_fit=None, production_feasibility=None))
    assert r["score"] == 80 and r["status"] == "provisional"
def test_none():
    assert score({})["status"] == "insufficiently_supported"
def test_range():
    with pytest.raises(ValueError): score({"relevance": 101})
