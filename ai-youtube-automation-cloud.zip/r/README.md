# AI YouTube Automation Cloud (Phase 1 foundation)
Implemented: FastAPI backend skeleton, SQLAlchemy models (users, content_ideas, publishing_jobs), CORS allow-list, /health, /trends/score (spec weights, renormalized provisional scores), tests.
Not implemented yet (see spec phases 2-6): Google OAuth, YouTube/Gemini integrations, analytics, video, scheduler, membership, Alembic migrations, React frontend.
## Run
cd backend && pip install -r requirements.txt && python -m pytest && uvicorn app.main:app --reload
